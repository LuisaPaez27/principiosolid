package PrincipioLiskov;

public interface ILoadRecursoPersistente {
    public void load();
}
