package PrincipioLiskov;

public interface RecursoPersistente {
    /*
    Esta clase se omite debe ser borrada
     */
    public void load();
    public void save();
}
