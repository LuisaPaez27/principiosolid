package PrincipioLiskov;

public interface ISaveRecursoPersistente {
    public void save();
}
